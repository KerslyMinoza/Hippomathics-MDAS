﻿using UnityEngine;
using System.Collections;

public class IslandMovement : MonoBehaviour {
	public Rigidbody2D rb;
	public float moveVertical = 0;
	public float speed = .05f;
	// Use this for initialization
	void Start () {
		
		rb = GetComponent<Rigidbody2D> ();
	}
	
	// Update is called once per frame
	void Update () {
		moveVertical = moveVertical - 0.1f;
		//Debug.Log (moveVertical);
		Vector2 movement = new Vector2 (0.0f, moveVertical);
		rb.AddForce (movement * speed);

	}
}
