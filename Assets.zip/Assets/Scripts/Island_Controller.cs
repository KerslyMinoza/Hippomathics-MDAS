﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class Island_Controller : MonoBehaviour {

	public GameObject island_go;
	//island_go = GameObject.Find("Island_GO");
	public List <GameObject> island_list = new List<GameObject>();


	//public TextMesh num;

	// Use this for initialization
	void Start () {
		
		//Debug.Log (rb);
		//---------Duplicates Island
		float x = -2.2F;
		float y = 0;
		GameObject island_name;

		Vector2 Pos = new Vector2 (x, y);
		for (int j = 1; j <= 15; j++) {
			if((j-1)%3 == 0){
				//starting
				if (j - 1 != 0) {
					Pos.y = Pos.y + 2;
				}
				Pos.x = -2.2F;
			}
			for (int i = 0; i < 1; i++) {
				Pos.x = Pos.x + 1;
				island_name = (GameObject)Instantiate (island_go, Pos, Quaternion.identity);
				island_name.name = j.ToString ();
				island_list.Add (island_name);
				island_go.GetComponent<TextMesh> ().text = j.ToString();

			}//end of i
		}//end of j
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
