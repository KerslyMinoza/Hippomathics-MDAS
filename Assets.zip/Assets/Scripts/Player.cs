﻿using UnityEngine;
using System.Collections;

public class Player : MonoBehaviour {


	public float jumpPower = 150;
	public bool grounded;


	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
	
	}
	void FixedUpdate(){
		float h = Input.GetAxis("Horizontal");

		//rb2d.AddForce(Vector2.right * speed * h);
	}
}
